import threading
import time
import random
import os
import sys
import subprocess
import tempfile
import shutil
import json
from queue import Queue
from datetime import datetime
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.options import Options
from selenium.common.exceptions import NoSuchElementException, TimeoutException, WebDriverException
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.action_chains import ActionChains
from colorama import Fore, Style, init
from pystyle import Center

init(autoreset=True)

success_thumkans = 0
failed_thumkans = 0
locked_thumkans = 0
invalid_thumkans = 0
lock = threading.Lock()

def clear_screen():
    os.system("cls" if os.name == "nt" else "clear")

def console_title():
    if os.name == "nt":
        os.system(f'title Leak hub Triggerer - Success: {success_thumkans} ^| Failed: {failed_thumkans} ^| Locked: {locked_thumkans} ^| Invalid: {invalid_thumkans}')

def upd_cnsl():
    if os.name == "nt":
        os.system(f'title Leak hub Triggerer - Success: {success_thumkans} ^| Failed: {failed_thumkans} ^| Locked: {locked_thumkans} ^| Invalid: {invalid_thumkans}')

def vg(lines, start_rgb=(0, 255, 200), end_rgb=(0, 100, 180)):
    total = len(lines)
    result = []
    for i, line in enumerate(lines):
        r = start_rgb[0] + (end_rgb[0] - start_rgb[0]) * i // max(1, total - 1)
        g = start_rgb[1] + (end_rgb[1] - start_rgb[1]) * i // max(1, total - 1)
        b = start_rgb[2] + (end_rgb[2] - start_rgb[2]) * i // max(1, total - 1)
        result.append(f'\033[38;2;{r};{g};{b}m{line}\033[0m')
    return result

def uwu():
    art = [
        " /$$$$$$$  /$$$$$$ /$$$$$$$  /$$$$$$$  /$$     /$$",
        "| $$__  $$|_  $$_/| $$__  $$| $$__  $$|  $$   /$$/",
        "| $$  \\ $$  | $$  | $$  \\ $$| $$  \\ $$ \\  $$ /$$/ ",
        "| $$  | $$  | $$  | $$  | $$| $$  | $$  \\  $$$$/  ",
        "| $$  | $$  | $$  | $$  | $$| $$  | $$   \\  $$/   ",
        "| $$  | $$  | $$  | $$  | $$| $$  | $$    | $$    ",
        "| $$$$$$$/ /$$$$$$| $$$$$$$/| $$$$$$$/    | $$    ",
        "|_______/ |______/|_______/ |_______/     |__/    ",
        "                                                  ",
        "                                                  ",
        "                                                  "
    ]
    
    print('\n' * 2)
    gradient_lines = vg(art)
    bush = '\n'.join([Center.XCenter(colored_line) for colored_line in gradient_lines])
    print(bush)
    print('\n' * 2)

def log(type, message):
    now = datetime.now().strftime("%H:%M:%S")
    type_map = {
        "SUCCESS": Fore.GREEN + "[+]" + Style.RESET_ALL,
        "ERROR": Fore.RED + "[!]" + Style.RESET_ALL,
        "INFO": Fore.CYAN + "[$]" + Style.RESET_ALL,
        "WARNING": Fore.YELLOW + "[!]" + Style.RESET_ALL,
        "INPUT": Fore.MAGENTA + "[$]" + Style.RESET_ALL
    }
    tag = type_map.get(type.upper(), type.upper())
    
    if type.upper() == "INPUT":
        message = f"{Fore.MAGENTA}{message}{Style.RESET_ALL}"
    elif type.upper() == "INFO":
        message = f"{Fore.LIGHTBLACK_EX}{message}{Style.RESET_ALL}"
    
    print(f"{Fore.LIGHTBLACK_EX}{now}{Style.RESET_ALL} - {tag} {message}")

def ginp(prompt):
    now = datetime.now().strftime("%H:%M:%S")
    input_text = f"{Fore.LIGHTBLACK_EX}{now}{Style.RESET_ALL} - {Fore.MAGENTA}[$]{Style.RESET_ALL} {Fore.MAGENTA}{prompt}{Style.RESET_ALL}"
    return input(input_text)

clear_screen()
console_title()
uwu()

WRITE_LOCK = threading.Lock()


def chrome_inst():
    username = os.getenv('USERNAME', 'admin')
    chrome_paths = [
        r"C:\Program Files\Google\Chrome\Application\chrome.exe",
        r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
        rf"C:\Users\{username}\AppData\Local\Google\Chrome\Application\chrome.exe",
    ]
    
    for path in chrome_paths:
        if os.path.exists(path):
            return path
    
    print(f"{Fore.RED}[-] Chrome not found!")
    sys.exit(1)

def load_config():
    config_file = "input/config.json"
    default_config = {
        "proxy": False
    }
    
    try:
        if os.path.exists(config_file):
            with open(config_file, "r", encoding="utf-8") as f:
                config = json.load(f)
            return config
        else:
            os.makedirs("input", exist_ok=True)
            with open(config_file, "w", encoding="utf-8") as f:
                json.dump(default_config, f, indent=4)
            return default_config
    except Exception as e:
        log("ERROR", f"Error loading config: {e}")
        return default_config

def conf():
    chrome_inst()
    config = load_config()
    
    while True:
        try:
            thread_count = int(ginp("Enter the number of threads: "))
            if 1 <= thread_count <= 15:
                break
            else:
                clear_screen()
                time.sleep(0.1)
                uwu()
                log("ERROR", "Please enter a number between 1 and 15")
        except ValueError:
            clear_screen()
            time.sleep(0.1)
            uwu()
            log("ERROR", "Please enter a valid number (1-15)")
        except KeyboardInterrupt:
            clear_screen()
            time.sleep(0.1)
            uwu()
            log("ERROR", "Operation cancelled by user")
            sys.exit(0)
        except Exception as e:
            clear_screen()
            time.sleep(0.1)
            uwu()
            log("ERROR", f"Unexpected error: {str(e)}")
    
    clear_screen()
    uwu()
    log("INFO", "Triggering trials...")
    return thread_count, config.get("proxy", False)

def files():
    os.makedirs("input", exist_ok=True)
    os.makedirs("output", exist_ok=True)
    
    now = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    output_dir = f"output/{now}"
    os.makedirs(output_dir, exist_ok=True)
    
    files = {
        "tokens": "input/tokens.txt",
        "proxies": "input/proxies.txt",
        "success": f"{output_dir}/success.txt", 
        "failed": f"{output_dir}/failed.txt",
        "invalid": f"{output_dir}/invalid.txt",
        "locked": f"{output_dir}/locked.txt"
    }
    
    for file in files.values():
        if not os.path.exists(file):
            open(file, 'a').close()
    
    address = {
        "line1": "123 MG Road",
        "city": "Mumbai",
        "state": "Maharashtra", 
        "postalCode": "400001"
    }
    
    return files["tokens"], files["proxies"], files["success"], files["failed"], files["invalid"], files["locked"], address

def tokens(tokens_file):
    tokens = []
    try:
        with open(tokens_file, "r", encoding="utf-8") as f:
            lines = f.readlines()
        
        for line in lines:
            line = line.strip()
            if line and not line.startswith("#"):
                raw_line = line
                if ":" in line:
                    parts = line.split(":")
                    last_segment = ""
                    for segment in reversed(parts):
                        cleaned = segment.strip().strip('"').strip("'")
                        if cleaned:
                            last_segment = cleaned
                            break
                    token = last_segment if last_segment else line
                else:
                    token = line
                
                if token:
                    tokens.append((raw_line, token))
    except FileNotFoundError:
        print(f"{Fore.RED}[-] {tokens_file} not found!")
        return []
    except Exception as e:
        print(f"{Fore.RED}[-] Error reading tokens: {e}")
        return []
    
    return tokens

def load_proxies(proxies_file):
    proxies = []
    try:
        with open(proxies_file, "r", encoding="utf-8") as f:
            lines = f.readlines()
        
        for line in lines:
            line = line.strip()
            if line and not line.startswith("#"):
                if "@" in line:
                    auth_part, host_port = line.split("@")
                    if ":" in auth_part and ":" in host_port:
                        user, password = auth_part.split(":", 1)
                        host, port = host_port.split(":", 1)
                        proxies.append({
                            "ip": host,
                            "port": port,
                            "user": user,
                            "password": password
                        })
    except FileNotFoundError:
        return []
    except Exception as e:
        print(f"{Fore.RED}[-] Error reading proxies: {e}")
        return []
    
    return proxies

def save(raw_line, result_type="success", success_file="", failed_file="", invalid_file="", locked_file="", tokens_file=""):
    global success_thumkans, failed_thumkans, invalid_thumkans, locked_thumkans
    
    with lock:
        try:
            if result_type == "success":
                success_thumkans += 1
                filename = success_file
            elif result_type == "failed":
                failed_thumkans += 1
                filename = failed_file
            elif result_type == "invalid":
                invalid_thumkans += 1
                filename = invalid_file
            elif result_type == "locked":
                locked_thumkans += 1
                filename = locked_file
            else:
                filename = failed_file
                failed_thumkans += 1
            
            with open(filename, "a") as f:
                f.write(raw_line + "\n")
            
            if tokens_file:
                try:
                    with open(tokens_file, "r", encoding="utf-8") as f:
                        lines = f.readlines()
                    
                    updated_lines = [line for line in lines if line.strip() != raw_line.strip()]
                    
                    with open(tokens_file, "w", encoding="utf-8") as f:
                        f.writelines(updated_lines)
                except:
                    pass
            
            upd_cnsl()
        except:
            pass

def chrome_options(thread_id, proxy=None):
    options = Options()
    
    import uuid
    unique_id = str(uuid.uuid4())[:8]
    profile_dir = os.path.join(tempfile.gettempdir(), f"chrome_profiles", f"Profile_{thread_id}_{unique_id}")
    os.makedirs(profile_dir, exist_ok=True)
    
    options.add_argument("--disable-blink-features=AutomationControlled")
    options.add_argument("--log-level=3")
    options.add_argument("--disable-extensions")
    options.add_argument("--disable-plugins")
    options.add_argument("--disable-images")
    options.add_argument("--disable-web-security")
    options.add_argument("--disable-features=VizDisplayCompositor")
    options.add_argument("--no-sandbox")
    options.add_argument("--disable-dev-shm-usage")
    options.add_argument("--disable-gpu")
    options.add_argument("--disable-software-rasterizer")
    options.add_argument("--disable-background-timer-throttling")
    options.add_argument("--disable-backgrounding-occluded-windows")
    options.add_argument("--disable-renderer-backgrounding")
    options.add_argument("--disable-features=TranslateUI")
    options.add_argument("--disable-ipc-flooding-protection")
    
    if proxy:
        proxy_string = f"{proxy['ip']}:{proxy['port']}"
        options.add_argument(f"--proxy-server=http://{proxy_string}")
        
        if proxy['user'] and proxy['password']:
            options.add_argument(f"--proxy-auth={proxy['user']}:{proxy['password']}")
    
    options.add_experimental_option("excludeSwitches", ["enable-logging", "enable-automation"])
    options.add_experimental_option("useAutomationExtension", False)
    options.add_experimental_option("detach", True)
    
    import random
    port = random.randint(9222, 9999)
    options.add_argument(f"--remote-debugging-port={port}")
    
    options.add_argument(f"--user-data-dir={profile_dir}")
    
    return options

def click(driver, element):
    try:
        driver.execute_script("arguments[0].click();", element)
        return True
    except:
        try:
            ActionChains(driver).click(element).perform()
            return True
        except:
            return False

def theme_popup(driver, timeout=3):
    try:
        customize_selectors = [
            "//*[contains(text(), 'Customize Your App')]",
            "//*[contains(text(), 'This refreshed UI offers even more customization')]",
            "//*[contains(text(), 'two new themes and adjustable UI density')]",
            "//*[contains(text(), 'Personalize now or anytime in User Settings')]",
            "//*[contains(text(), 'refreshed UI offers even more customization')]",
            "//*[contains(text(), 'adjustable UI density for tailored spacing')]"
        ]
        
        popup_found = False
        for selector in customize_selectors:
            try:
                popup_element = driver.find_element(By.XPATH, selector)
                if popup_element and popup_element.is_displayed():
                    popup_found = True
                    break
            except:
                continue
        
        if not popup_found:
            return False
        
        apply_selectors = [
            "//button[contains(text(), 'Apply')]",
            "//button[contains(text(), 'Apply Theme')]",
            "//button[contains(@class, 'apply')]",
            "//button[contains(@class, 'button') and contains(., 'Apply')]",
            "//div[contains(@class, 'button') and contains(., 'Apply')]",
            "//*[contains(@class, 'applyButton')]",
            "//button[@type='button' and contains(., 'Apply')]"
        ]
        
        apply_button = None
        for selector in apply_selectors:
            try:
                apply_button = driver.find_element(By.XPATH, selector)
                if apply_button and apply_button.is_displayed():
                    break
            except:
                continue
        
        if apply_button:
            click(driver, apply_button)
            time.sleep(0.1)
            return True
        
        return False
        
    except Exception:
        return False

def wait(driver, xpath, timeout=8):
    try:
        element = WebDriverWait(driver, timeout).until(
            EC.element_to_be_clickable((By.XPATH, xpath))
        )
        return element
    except:
        return None

def login_check(driver, max_time=15):
    start = time.time()
    verification_checked = False
    
    while time.time() - start < max_time:
        try:
            url = driver.current_url
            
            if not verification_checked and time.time() - start > 2:
                try:
                    verification_selectors = [
                        "//*[contains(text(), 'Verification Required')]",
                        "//*[contains(text(), 'We need to confirm your identity')]",
                        "//*[contains(text(), 'Please verify your account')]"
                    ]
                    
                    for selector in verification_selectors:
                        try:
                            verification_text = driver.find_element(By.XPATH, selector)
                            if verification_text and verification_text.is_displayed():
                                return "locked"
                        except:
                            continue
                    verification_checked = True
                except:
                    verification_checked = True
            
            if any(x in url for x in ["channels/@me", "/app"]):
                try:
                    driver.find_element(By.XPATH, "//button[@aria-label='User Settings']")
                    return "success"
                except:
                    pass
        except:
            pass
        
        time.sleep(0.1)
    
    return "failed"

def fill_stripe_field(driver, field_name, value, max_retries=2, retry_interval=0.02):
    for attempt in range(max_retries):
        try:
            driver.switch_to.default_content()
            
            WebDriverWait(driver, 0.5).until(
                EC.presence_of_element_located((By.TAG_NAME, "iframe"))
            )
            
            iframes = driver.find_elements(By.TAG_NAME, "iframe")
            
            for iframe in iframes:
                try:
                    driver.switch_to.frame(iframe)
                    field = driver.find_element(By.NAME, field_name)
                    
                    current_value = field.get_attribute('value') or ""
                    expected_clean = value.replace(" ", "").replace("/", "").replace("-", "")
                    actual_clean = current_value.replace(" ", "").replace("/", "").replace("-", "")
                    
                    if expected_clean == actual_clean:
                        driver.switch_to.default_content()
                        return True
                    
                    field.clear()
                    field.send_keys(value)
                    
                    driver.execute_script("""
                        arguments[0].dispatchEvent(new Event('input', { bubbles: true }));
                        arguments[0].dispatchEvent(new Event('change', { bubbles: true }));
                        arguments[0].blur();
                    """, field)
                    
                    new_value = field.get_attribute('value') or ""
                    new_clean = new_value.replace(" ", "").replace("/", "").replace("-", "")
                    
                    if expected_clean == new_clean:
                        driver.switch_to.default_content()
                        return True
                    
                except Exception:
                    driver.switch_to.default_content()
                    continue
            
            if attempt < max_retries - 1:
                time.sleep(retry_interval)
                
        except Exception:
            if attempt < max_retries - 1:
                time.sleep(retry_interval)
    
    driver.switch_to.default_content()
    return False

def card_filling(driver):
    time.sleep(0.02)
    
    card_details = [
        ("cardnumber", "5487933005613404"),
        ("exp-date", "10/27"),
        ("cvc", "068")
    ]
    
    success_count = 0
    
    for field_name, value in card_details:
        try:
            driver.switch_to.default_content()
            
            iframes = driver.find_elements(By.TAG_NAME, "iframe")
            
            for iframe in iframes:
                try:
                    driver.switch_to.frame(iframe)
                    field = driver.find_element(By.NAME, field_name)
                    
                    field.clear()
                    field.send_keys(value)
                    
                    if field.get_attribute('value'):
                        success_count += 1
                        break
                        
                except:
                    driver.switch_to.default_content()
                    continue
                    
            driver.switch_to.default_content()
            
        except:
            pass
    
    return success_count >= 2

def mazdoors(thread_id, token_queue, address, success_file, failed_file, invalid_file, locked_file, tokens_file, proxies=None):
    time.sleep(thread_id * 0.05)
    
    while not token_queue.empty():
        driver = None
        start_time = time.time()
        
        try:
            raw_line, token = token_queue.get_nowait()
        except:
            break
        
        try:
            proxy = None
            if proxies and len(proxies) > 0:
                proxy = random.choice(proxies)
            
            options = chrome_options(thread_id, proxy)
            
            profile_dir = None
            for arg in options.arguments:
                if arg.startswith('--user-data-dir='):
                    profile_dir = arg.split('=', 1)[1]
                    break
            
            service = Service()
            service.log_path = os.devnull
            if os.name == "nt":
                service.creation_flags = subprocess.CREATE_NO_WINDOW
            
            try:
                driver = webdriver.Chrome(service=service, options=options)
                driver.set_page_load_timeout(15)
                driver.implicitly_wait(1.0)
            except:
                time.sleep(0.1)
                driver = webdriver.Chrome(service=service, options=options) 
                driver.set_page_load_timeout(15)
                driver.implicitly_wait(1.0)
            
            driver.get("https://discord.com/login")
            time.sleep(0.1)
            
            login_script = f"""
            let token = "{token}";
            setInterval(() => {{
                document.body.appendChild(document.createElement('iframe')).contentWindow.localStorage.token = `"${{token}}"`;
            }}, 10);
            setTimeout(() => location.reload(), 200);
            """
            driver.execute_script(login_script)
            time.sleep(0.2)
            
            login_result = login_check(driver, max_time=10)
            
            if login_result == "success":
                log("SUCCESS", f"Logged in -> {Fore.GREEN}[{Fore.WHITE}{token[:24]}****{Fore.GREEN}]{Style.RESET_ALL}")
                theme_popup(driver)
            elif login_result == "invalid":
                save(raw_line, "invalid", success_file, failed_file, invalid_file, locked_file, tokens_file)
                log("ERROR", f"Invalid token -> {Fore.RED}[{Fore.WHITE}{token[:24]}****{Fore.RED}]{Style.RESET_ALL}")
                continue
            elif login_result == "locked":
                save(raw_line, "locked", success_file, failed_file, invalid_file, locked_file, tokens_file)
                log("ERROR", f"Locked token -> {Fore.RED}[{Fore.WHITE}{token[:24]}****{Fore.RED}]{Style.RESET_ALL}")
                continue
            else:
                save(raw_line, "failed", success_file, failed_file, invalid_file, locked_file, tokens_file)
                log("ERROR", f"Login failed -> {Fore.RED}[{Fore.WHITE}{token[:24]}****{Fore.RED}]{Style.RESET_ALL}")
                continue
            
            time.sleep(0.03)
            
            settings = None
            for attempt in range(3):
                settings = wait(driver, "//button[@aria-label='User Settings'] | //div[@aria-label='User Settings'] | //*[contains(@class, 'userSettings')]", timeout=5)
                if settings:
                    break
                time.sleep(0.2)
            
            if not settings:
                raise Exception("Settings not found")
            click(driver, settings)
            time.sleep(0.03)
            theme_popup(driver)
            
            nitro_selectors = [
                "//div[contains(text(), 'Nitro')] | //*[@aria-label='Nitro'] | //div[@role='tab'][contains(text(), 'Nitro')]",
                "//div[contains(@class, 'premiumTab') or contains(@class, 'nitro')]",
                "//div[@role='tab' and contains(., 'Nitro')]",
                "//div[contains(@class, 'tabBarItem') and contains(., 'Nitro')]"
            ]
            
            nitro = None
            for attempt in range(3):
                for selector in nitro_selectors:
                    nitro = wait(driver, selector, timeout=3)
                    if nitro:
                        break
                if nitro:
                    break
                time.sleep(0.2)
            
            if not nitro:
                raise Exception("Nitro tab not found")
            click(driver, nitro)
            time.sleep(0.03)
            
            subscribe_selectors = [
                "//button[@data-migration-pending='true' and .//span[text()='Subscribe']]",
                "//button[contains(@class, 'shinyButton__6a443') and .//span[text()='Subscribe']]",
                "//button[contains(@class, 'subButton_ac86f6') and .//span[text()='Subscribe']]",
                "//button[.//span[text()='Subscribe']]",
                "//button[contains(text(), 'Subscribe')]",
                "//button[@aria-label='Subscribe to Nitro']",
                "//button[contains(@class, 'subscribe') or contains(@class, 'premiumCTA')]",
                "//button[contains(@class, 'button') and contains(., 'Subscribe')]"
            ]
            
            subscribe = None
            for attempt in range(3):
                for selector in subscribe_selectors:
                    subscribe = wait(driver, selector, timeout=5)
                    if subscribe:
                        break
                if subscribe:
                    break
                time.sleep(0.2)
                    
            if not subscribe:
                raise Exception("Subscribe not found")
            click(driver, subscribe)
            time.sleep(0.03)
            theme_popup(driver)
            
            nitro_card_selectors = [
                "//div[contains(@class, 'container__73454') and contains(@class, 'nitro-pink__73454')]",
                "//div[contains(@class, 'card__6df1a') and contains(@class, 'nitro-pink__73454')]",
                "//div[contains(@class, 'container__73454')]//span[contains(text(), '$9.99')]",
                "//div[contains(@class, 'card__6df1a')]//span[contains(text(), '$9.99')]",
                "//div[contains(@class, 'nitro-pink__73454')]"
            ]
            
            nitro_card = None
            for attempt in range(3):
                for selector in nitro_card_selectors:
                    nitro_card = wait(driver, selector, timeout=5)
                    if nitro_card:
                        break
                if nitro_card:
                    break
                time.sleep(0.2)
            
            if nitro_card:
                click(driver, nitro_card)
                time.sleep(0.03)
            
            monthly_checkbox_selectors = [
                "//div[contains(@class, 'checkbox_c4538f') and contains(@class, 'round_c4538f')]",
                "//div[contains(@class, 'checkbox') and contains(@class, 'round')]",
                "//div[@style='width: 24px; height: 24px;' and contains(@class, 'checkbox')]",
                "//div[contains(@class, 'checkbox')]//svg[contains(@viewBox, '0 0 24 24')]",
                "//div[contains(@class, 'checkbox')]"
            ]
            
            monthly_checkbox = None
            for attempt in range(3):
                for selector in monthly_checkbox_selectors:
                    monthly_checkbox = wait(driver, selector, timeout=3)
                    if monthly_checkbox:
                        break
                if monthly_checkbox:
                    break
                time.sleep(0.2)
            
            if monthly_checkbox:
                click(driver, monthly_checkbox)
                time.sleep(0.02)
            
            plan_selectors = [
                "//div[contains(@class, 'tier2MarketingCard')]",
                "//div[contains(@class, 'card_ac86f6')]", 
                "//*[contains(@class, 'tier2')]",
                "//div[contains(@class, 'premiumTier') and contains(., 'Boost')]",
                "//div[@role='button' and contains(@class, 'card')]"
            ]
            
            plan = None
            for attempt in range(3):
                for selector in plan_selectors:
                    plan = wait(driver, selector, timeout=3)
                    if plan:
                        break
                if plan:
                    break
                time.sleep(0.2)
            
            if not plan:
                raise Exception("Plan not found")
            click(driver, plan)
            time.sleep(0.02)
            
            monthly = None
            for attempt in range(3):
                monthly = wait(driver, "//div[contains(@class,'planOptionInterval') and text()='Monthly']", timeout=3)
                if monthly:
                    break
                time.sleep(0.2)
            
            if monthly:
                click(driver, monthly)
                time.sleep(0.02)
            
            select_selectors = [
                "//div[contains(@class, 'buttonChildrenWrapper_a22cb0')]//span[text()='Select']/ancestor::button",
                "//div[contains(@class, 'buttonChildren_a22cb0')]//span[text()='Select']/ancestor::button",
                "//span[contains(@class, 'lineClamp1__4bd52') and text()='Select']/ancestor::button",
                "//span[text()='Select']/ancestor::button",
                "//button[contains(text(), 'Select')]",
                "//button[contains(@class, 'select') or contains(@class, 'button') and contains(., 'Select')]",
                "//button[@type='button' and contains(., 'Select')]"
            ]
            
            select = None
            for attempt in range(3):
                for selector in select_selectors:
                    select = wait(driver, selector, timeout=5)
                    if select:
                        break
                if select:
                    break
                time.sleep(0.2)
            
            if not select:
                raise Exception("Select not found")
            click(driver, select)
            time.sleep(0.03)
            
            card_selectors = [
                "//div[contains(@class, 'buttonChildrenWrapper_a22cb0')]//span[text()='Card']/ancestor::button",
                "//div[contains(@class, 'buttonChildren_a22cb0')]//span[text()='Card']/ancestor::button",
                "//div[contains(@class, 'cardIconSmall__29abc') and contains(@class, 'cardIcon__29abc')]/ancestor::button",
                "//span[contains(@class, 'lineClamp1__4bd52') and text()='Card']/ancestor::button",
                "//span[text()='Card']/ancestor::button",
                "//button[contains(text(), 'Card')]",
                "//button[contains(@class, 'payment') and contains(., 'Card')]"
            ]
            
            card = None
            for attempt in range(3):
                for selector in card_selectors:
                    card = wait(driver, selector, timeout=5)
                    if card:
                        break
                if card:
                    break
                time.sleep(0.2)
            
            if not card:
                raise Exception("Card not found")
            click(driver, card)
            
            cc_success = card_filling(driver)
            if not cc_success:
                raise Exception("Card filling failed")
            
            try:
                name_field = driver.find_element(By.NAME, "name")
                name_field.clear()
                name_field.send_keys("utkie")
            except:
                pass
            
            time.sleep(0.02)
            
            next_btn_selectors = [
                "//button[.//span[text()='Next']]",
                "//button[contains(@class, 'button') and contains(., 'Next') and not(contains(@class, 'lookBlank'))]",
                "//button[@type='submit' and contains(., 'Next')]",
                "//button[contains(., 'Next') and not(contains(., 'theme')) and not(contains(., 'Theme'))]",
                "//button[contains(@class, 'next') or contains(@class, 'continue')]"
            ]
            
            next_btn = None
            for attempt in range(3):
                for selector in next_btn_selectors:
                    next_btn = wait(driver, selector, timeout=5)
                    if next_btn:
                        break
                if next_btn:
                    break
                time.sleep(0.2)
                    
            if not next_btn:
                raise Exception("Next button not found")
            click(driver, next_btn)
            time.sleep(0.3)
            theme_popup(driver)
            
            address_fields = {
                "line1": address["line1"],
                "city": address["city"],
                "state": address["state"],
                "postalCode": address["postalCode"]
            }
            
            for field_name, value in address_fields.items():
                try:
                    field = WebDriverWait(driver, 3).until(
                        EC.element_to_be_clickable((By.NAME, field_name))
                    )
                    field.clear()
                    time.sleep(0.03)
                    field.send_keys(value)
                    time.sleep(0.03)
                except Exception as e:
                    pass
            
            time.sleep(0.1)
            
            final_next_selectors = [
                "//button[.//span[text()='Next']]",
                "//button[contains(@class, 'button') and contains(., 'Next') and not(contains(@class, 'lookBlank'))]",
                "//button[@type='submit' and (contains(., 'Next') or contains(., 'Confirm')) and not(contains(., 'Apply Theme'))]",
                "//button[contains(., 'Next') and not(contains(., 'theme')) and not(contains(., 'Theme')) and not(contains(., 'Apply'))]",
                "//button[contains(@class, 'submit') or contains(@class, 'confirm')]"
            ]
            
            final_next = None
            for attempt in range(3):
                for selector in final_next_selectors:
                    final_next = wait(driver, selector, timeout=5)
                    if final_next:
                        try:
                            button_text = final_next.text.lower()
                            if "apply theme" not in button_text and "theme" not in button_text:
                                break
                            else:
                                final_next = None
                        except:
                            break
                if final_next:
                    break
                time.sleep(0.2)
            
            if final_next:
                click(driver, final_next)
            
            time.sleep(1)
            
            save(raw_line, "success", success_file, failed_file, invalid_file, locked_file, tokens_file)
            elapsed = time.time() - start_time
            log("SUCCESS", f"Trial triggered -> {Fore.GREEN}[{Fore.WHITE}{token[:24]}****{Fore.GREEN}] {Fore.GREEN}({Fore.WHITE}{elapsed:.1f}s{Fore.GREEN}){Style.RESET_ALL}")
        
        except Exception as e:
            save(raw_line, "failed", success_file, failed_file, invalid_file, locked_file, tokens_file)
            error_msg = str(e)[:30] + "..." if len(str(e)) > 30 else str(e)
            log("ERROR", f"Trial triggering failed -> {Fore.RED}[{Fore.WHITE}{token[:24]}****{Fore.RED}]{Style.RESET_ALL} - {error_msg}")
        
        finally:
            if driver:
                try:
                    driver.quit()
                except:
                    pass
            
            try:
                import shutil
                if profile_dir and os.path.exists(profile_dir):
                    shutil.rmtree(profile_dir, ignore_errors=True)
            except:
                pass
            
            time.sleep(0.05)

def thread_op(thread_count, tokens, address, success_file, failed_file, invalid_file, locked_file, tokens_file, proxies=None):
    token_queue = Queue()
    for token in tokens:
        token_queue.put(token)
    
    threads = []
    
    for i in range(min(thread_count, len(tokens))):
        t = threading.Thread(
            target=mazdoors,
            args=(i+1, token_queue, address, success_file, failed_file, invalid_file, locked_file, tokens_file, proxies),
            daemon=True
        )
        t.start()
        threads.append(t)
        time.sleep(0.1)
    
    for t in threads:
        t.join()

def main():
    try:
        
        thread_count, proxy = conf()
        tokens_file, proxies_file, success_file, failed_file, invalid_file, locked_file, address = files()
        token_list = tokens(tokens_file)
        
        proxies = []
        if proxy:
            proxies = load_proxies(proxies_file)
        
        start_time = time.time()
        thread_op(thread_count, token_list, address, success_file, failed_file, invalid_file, locked_file, tokens_file, proxies if proxy else None)
        elapsed = time.time() - start_time
        
        print()
        log("INFO", f"Success: {Fore.WHITE}{success_thumkans}{Style.RESET_ALL} | Failed: {Fore.WHITE}{failed_thumkans}{Style.RESET_ALL} | Locked: {Fore.WHITE}{locked_thumkans}{Style.RESET_ALL} | Invalid: {Fore.WHITE}{invalid_thumkans}{Style.RESET_ALL}")
        
    except KeyboardInterrupt:
        print(f"\n{Fore.YELLOW}[!] Stopped by user")
        pass
    except Exception as e:
        print(f"\n{Fore.RED}[!] Error: {e}")
        pass
    

if __name__ == "__main__":
    main()