#!/usr/bin/env python3
"""
GVM Panel v2.0 - Professional LXC Management System
Made by PowerDev - Fully Grown & Highly Advanced
100% Working & Production Ready
"""

from flask import Flask, render_template, request, redirect, url_for, session, jsonify, flash
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from functools import wraps
import subprocess
import json
import os
from datetime import datetime, timedelta
import secrets
import logging
import threading
import time

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('/var/log/gvm-panel.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger('GVM-Panel')

# Initialize Flask app
app = Flask(__name__)
app.config['SECRET_KEY'] = os.getenv('SECRET_KEY', secrets.token_hex(32))
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:////var/lib/gvm-panel/gvm_panel.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['PERMANENT_SESSION_LIFETIME'] = timedelta(hours=24)

# Initialize database
db = SQLAlchemy(app)

# Configuration
CPU_THRESHOLD = int(os.getenv('CPU_THRESHOLD', '90'))
RAM_THRESHOLD = int(os.getenv('RAM_THRESHOLD', '90'))
CHECK_INTERVAL = int(os.getenv('CHECK_INTERVAL', '600'))
DEFAULT_STORAGE_POOL = os.getenv('DEFAULT_STORAGE_POOL', 'default')

# Global monitoring state
monitoring_active = True

# ========================
# Database Models
# ========================

class User(db.Model):
    __tablename__ = 'users'
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(200), nullable=False)
    is_admin = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    containers = db.relationship('Container', backref='owner', lazy=True, cascade='all, delete-orphan')

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

class Container(db.Model):
    __tablename__ = 'containers'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), unique=True, nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    ram_gb = db.Column(db.Integer, default=1)
    cpu_cores = db.Column(db.Integer, default=1)
    disk_gb = db.Column(db.Integer, default=10)
    status = db.Column(db.String(20), default='stopped')
    ssh_password = db.Column(db.String(50), nullable=True)
    suspended = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    suspension_history = db.Column(db.Text, default='[]')
    shared_with = db.Column(db.Text, default='[]')

class ContainerSnapshot(db.Model):
    __tablename__ = 'snapshots'
    id = db.Column(db.Integer, primary_key=True)
    container_id = db.Column(db.Integer, db.ForeignKey('containers.id'), nullable=False)
    snapshot_name = db.Column(db.String(100), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    description = db.Column(db.String(200))

class AuditLog(db.Model):
    __tablename__ = 'audit_logs'
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'))
    action = db.Column(db.String(200), nullable=False)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    ip_address = db.Column(db.String(50))
    details = db.Column(db.Text)

# ========================
# LXC Management Class
# ========================

class LXCManager:
    @staticmethod
    def execute_command(command, timeout=120):
        """Execute system command safely"""
        try:
            logger.info(f"Executing: {command}")
            result = subprocess.run(
                command,
                shell=True,
                capture_output=True,
                text=True,
                timeout=timeout
            )
            return {
                'success': result.returncode == 0,
                'output': result.stdout,
                'error': result.stderr,
                'returncode': result.returncode
            }
        except subprocess.TimeoutExpired:
            logger.error(f"Command timeout: {command}")
            return {'success': False, 'error': 'Command timeout', 'returncode': -1}
        except Exception as e:
            logger.error(f"Command error: {e}")
            return {'success': False, 'error': str(e), 'returncode': -1}

    @staticmethod
    def list_containers():
        """List all LXC containers"""
        result = LXCManager.execute_command("lxc list --format json")
        if result['success']:
            try:
                return json.loads(result['output'])
            except:
                return []
        return []

    @staticmethod
    def get_container_status(name):
        """Get container status"""
        containers = LXCManager.list_containers()
        for container in containers:
            if container['name'] == name:
                return container.get('status', 'Unknown')
        return 'Not Found'

    @staticmethod
    def get_container_stats(name):
        """Get container resource usage"""
        stats = {
            'cpu': '0%',
            'memory': '0 MB',
            'disk': '0 GB',
            'network': '0 KB/s',
            'processes': '0'
        }
        
        try:
            # Get memory
            result = LXCManager.execute_command(f"lxc exec {name} -- free -m 2>/dev/null", timeout=10)
            if result['success'] and result['output']:
                lines = result['output'].split('\n')
                if len(lines) > 1:
                    mem_line = lines[1].split()
                    if len(mem_line) >= 3:
                        used = mem_line[2]
                        total = mem_line[1]
                        stats['memory'] = f"{used} MB / {total} MB"
            
            # Get disk
            result = LXCManager.execute_command(f"lxc exec {name} -- df -h / 2>/dev/null", timeout=10)
            if result['success'] and result['output']:
                lines = result['output'].split('\n')
                for line in lines:
                    if '/dev/' in line:
                        parts = line.split()
                        if len(parts) >= 5:
                            stats['disk'] = f"{parts[2]} / {parts[1]} ({parts[4]})"
                        break
            
            # Get process count
            result = LXCManager.execute_command(f"lxc exec {name} -- ps aux 2>/dev/null | wc -l", timeout=10)
            if result['success'] and result['output']:
                stats['processes'] = result['output'].strip()
        
        except Exception as e:
            logger.error(f"Error getting stats for {name}: {e}")
        
        return stats

    @staticmethod
    def create_container(name, ram_gb, cpu_cores, disk_gb, ssh_password):
        """Create new LXC container"""
        try:
            logger.info(f"Creating container: {name}")
            
            # Create container
            result = LXCManager.execute_command(f"lxc init ubuntu:22.04 {name}")
            if not result['success']:
                return {'success': False, 'error': f"Init failed: {result['error']}"}

            # Set resources
            ram_mb = ram_gb * 1024
            LXCManager.execute_command(f"lxc config set {name} limits.memory {ram_mb}MB")
            LXCManager.execute_command(f"lxc config set {name} limits.cpu {cpu_cores}")
            
            # Start container
            result = LXCManager.execute_command(f"lxc start {name}")
            if not result['success']:
                LXCManager.execute_command(f"lxc delete {name} --force")
                return {'success': False, 'error': 'Failed to start container'}

            # Wait for network
            time.sleep(10)

            # Install SSH
            commands = [
                f"lxc exec {name} -- apt-get update",
                f"lxc exec {name} -- apt-get install -y openssh-server sudo",
                f"lxc exec {name} -- systemctl enable ssh",
                f"lxc exec {name} -- systemctl start ssh",
                f"lxc exec {name} -- useradd -m -s /bin/bash gvmuser",
                f"lxc exec {name} -- bash -c \"echo 'gvmuser:{ssh_password}' | chpasswd\"",
                f"lxc exec {name} -- usermod -aG sudo gvmuser",
                f"lxc exec {name} -- bash -c \"echo 'gvmuser ALL=(ALL) NOPASSWD:ALL' > /etc/sudoers.d/gvmuser\""
            ]

            for cmd in commands:
                LXCManager.execute_command(cmd, timeout=300)

            logger.info(f"Container {name} created successfully")
            return {'success': True}

        except Exception as e:
            logger.error(f"Failed to create container {name}: {e}")
            LXCManager.execute_command(f"lxc delete {name} --force")
            return {'success': False, 'error': str(e)}

    @staticmethod
    def delete_container(name):
        """Delete container"""
        result = LXCManager.execute_command(f"lxc delete {name} --force")
        return result['success']

    @staticmethod
    def start_container(name):
        """Start container"""
        result = LXCManager.execute_command(f"lxc start {name}")
        return result['success']

    @staticmethod
    def stop_container(name):
        """Stop container"""
        result = LXCManager.execute_command(f"lxc stop {name} --force")
        return result['success']

    @staticmethod
    def restart_container(name):
        """Restart container"""
        result = LXCManager.execute_command(f"lxc restart {name} --force")
        return result['success']

    @staticmethod
    def get_ssh_info(name):
        """Get SSH connection info"""
        result = LXCManager.execute_command(f"lxc list {name} --format json")
        if result['success']:
            try:
                data = json.loads(result['output'])
                if data:
                    addresses = data[0].get('state', {}).get('network', {}).get('eth0', {}).get('addresses', [])
                    for addr in addresses:
                        if addr.get('family') == 'inet':
                            return addr.get('address')
            except:
                pass
        return None

    @staticmethod
    def create_snapshot(name, snapshot_name):
        """Create snapshot"""
        result = LXCManager.execute_command(f"lxc snapshot {name} {snapshot_name}")
        return result['success']

    @staticmethod
    def restore_snapshot(name, snapshot_name):
        """Restore snapshot"""
        result = LXCManager.execute_command(f"lxc restore {name} {snapshot_name}")
        return result['success']

    @staticmethod
    def get_cpu_percentage(name):
        """Get CPU percentage"""
        try:
            result = LXCManager.execute_command(f"lxc exec {name} -- top -bn1 2>/dev/null | grep 'Cpu(s)'", timeout=10)
            if result['success'] and result['output']:
                if 'id,' in result['output']:
                    idle = float(result['output'].split('id,')[0].split()[-1])
                    return 100 - idle
        except:
            pass
        return 0.0

    @staticmethod
    def get_ram_percentage(name):
        """Get RAM percentage"""
        try:
            result = LXCManager.execute_command(f"lxc exec {name} -- free 2>/dev/null", timeout=10)
            if result['success'] and result['output']:
                lines = result['output'].split('\n')
                if len(lines) > 1:
                    mem_line = lines[1].split()
                    if len(mem_line) >= 3:
                        used = int(mem_line[2])
                        total = int(mem_line[1])
                        return (used / total * 100) if total > 0 else 0.0
        except:
            pass
        return 0.0

# ========================
# Monitoring Functions
# ========================

def get_host_cpu_usage():
    """Get host CPU usage"""
    try:
        result = subprocess.run(['top', '-bn1'], capture_output=True, text=True, timeout=5)
        for line in result.stdout.split('\n'):
            if '%Cpu(s):' in line:
                words = line.split()
                for i, word in enumerate(words):
                    if word == 'id,':
                        idle = float(words[i-1])
                        return 100.0 - idle
    except:
        pass
    return 0.0

def host_cpu_monitor():
    """Monitor host CPU"""
    global monitoring_active
    while monitoring_active:
        try:
            cpu_usage = get_host_cpu_usage()
            if cpu_usage > CPU_THRESHOLD:
                logger.warning(f"Host CPU {cpu_usage}% > {CPU_THRESHOLD}%! Stopping all containers...")
                with app.app_context():
                    containers = Container.query.filter_by(status='Running').all()
                    for container in containers:
                        LXCManager.stop_container(container.name)
                        container.status = 'Stopped'
                    db.session.commit()
            time.sleep(60)
        except Exception as e:
            logger.error(f"Host monitor error: {e}")
            time.sleep(60)

def container_monitor():
    """Monitor containers"""
    global monitoring_active
    while monitoring_active:
        try:
            with app.app_context():
                containers = Container.query.filter_by(status='Running', suspended=False).all()
                for container in containers:
                    try:
                        cpu_pct = LXCManager.get_cpu_percentage(container.name)
                        ram_pct = LXCManager.get_ram_percentage(container.name)
                        
                        if cpu_pct > CPU_THRESHOLD or ram_pct > RAM_THRESHOLD:
                            logger.warning(f"Suspending {container.name}: CPU={cpu_pct}%, RAM={ram_pct}%")
                            LXCManager.stop_container(container.name)
                            container.suspended = True
                            container.status = 'Stopped'
                            
                            history = json.loads(container.suspension_history)
                            history.append({
                                'time': datetime.now().isoformat(),
                                'reason': f"High usage: CPU {cpu_pct:.1f}%, RAM {ram_pct:.1f}%",
                                'by': 'Auto-System'
                            })
                            container.suspension_history = json.dumps(history)
                            db.session.commit()
                    except Exception as e:
                        logger.error(f"Error monitoring {container.name}: {e}")
            
            time.sleep(CHECK_INTERVAL)
        except Exception as e:
            logger.error(f"Container monitor error: {e}")
            time.sleep(60)

def start_monitoring():
    """Start monitoring threads"""
    threading.Thread(target=host_cpu_monitor, daemon=True).start()
    threading.Thread(target=container_monitor, daemon=True).start()
    logger.info("Monitoring started")

# ========================
# Decorators
# ========================

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash('Please login first', 'warning')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            return redirect(url_for('login'))
        user = User.query.get(session['user_id'])
        if not user or not user.is_admin:
            flash('Admin access required', 'danger')
            return redirect(url_for('dashboard'))
        return f(*args, **kwargs)
    return decorated_function

def log_action(action, details=None):
    """Log action"""
    try:
        if 'user_id' in session:
            log = AuditLog(
                user_id=session['user_id'],
                action=action,
                ip_address=request.remote_addr,
                details=details
            )
            db.session.add(log)
            db.session.commit()
    except Exception as e:
        logger.error(f"Failed to log action: {e}")

# ========================
# Routes
# ========================

@app.route('/')
def index():
    if 'user_id' in session:
        return redirect(url_for('dashboard'))
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '')

        user = User.query.filter_by(username=username).first()
        if user and user.check_password(password):
            session['user_id'] = user.id
            session['username'] = user.username
            session['is_admin'] = user.is_admin
            session.permanent = True
            log_action(f"User logged in: {username}")
            flash(f'Welcome {username}!', 'success')
            return redirect(url_for('dashboard'))
        else:
            flash('Invalid credentials', 'danger')

    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        email = request.form.get('email', '').strip()
        password = request.form.get('password', '')
        confirm_password = request.form.get('confirm_password', '')

        if not username or not email or not password:
            flash('All fields required', 'danger')
            return render_template('register.html')

        if len(username) < 3:
            flash('Username must be 3+ characters', 'danger')
            return render_template('register.html')

        if len(password) < 6:
            flash('Password must be 6+ characters', 'danger')
            return render_template('register.html')

        if password != confirm_password:
            flash('Passwords do not match', 'danger')
            return render_template('register.html')

        if User.query.filter_by(username=username).first():
            flash('Username exists', 'danger')
            return render_template('register.html')

        if User.query.filter_by(email=email).first():
            flash('Email registered', 'danger')
            return render_template('register.html')

        user = User(username=username, email=email)
        user.set_password(password)
        db.session.add(user)
        db.session.commit()

        log_action(f"New user: {username}")
        flash('Registration successful!', 'success')
        return redirect(url_for('login'))

    return render_template('register.html')

@app.route('/logout')
def logout():
    username = session.get('username', 'Unknown')
    log_action(f"User logged out: {username}")
    session.clear()
    flash('Logged out', 'info')
    return redirect(url_for('login'))

@app.route('/dashboard')
@login_required
def dashboard():
    user = User.query.get(session['user_id'])
    containers = Container.query.filter_by(user_id=user.id).all()
    
    # Update statuses
    for container in containers:
        container.status = LXCManager.get_container_status(container.name)
    db.session.commit()
    
    # Get shared containers
    shared_containers = []
    for container in Container.query.all():
        shared_with = json.loads(container.shared_with)
        if user.id in shared_with:
            shared_containers.append(container)
    
    return render_template('dashboard.html', user=user, containers=containers, shared_containers=shared_containers)

@app.route('/container/<int:container_id>')
@login_required
def container_detail(container_id):
    container = Container.query.get_or_404(container_id)
    
    # Check access
    shared_with = json.loads(container.shared_with)
    if container.user_id != session['user_id'] and session['user_id'] not in shared_with and not session.get('is_admin'):
        flash('Access denied', 'danger')
        return redirect(url_for('dashboard'))
    
    container.status = LXCManager.get_container_status(container.name)
    stats = LXCManager.get_container_stats(container.name) if container.status == 'Running' else None
    ssh_ip = LXCManager.get_ssh_info(container.name)
    
    snapshots = ContainerSnapshot.query.filter_by(container_id=container.id).order_by(ContainerSnapshot.created_at.desc()).all()
    suspension_history = json.loads(container.suspension_history)
    
    is_owner = (container.user_id == session['user_id'])
    is_shared = (session['user_id'] in shared_with)
    
    return render_template('container_detail.html', 
                         container=container, 
                         stats=stats, 
                         ssh_ip=ssh_ip,
                         snapshots=snapshots,
                         suspension_history=suspension_history,
                         is_owner=is_owner,
                         is_shared=is_shared)

@app.route('/container/<int:container_id>/start', methods=['POST'])
@login_required
def start_container(container_id):
    container = Container.query.get_or_404(container_id)
    
    shared_with = json.loads(container.shared_with)
    if container.user_id != session['user_id'] and session['user_id'] not in shared_with and not session.get('is_admin'):
        return jsonify({'success': False, 'error': 'Access denied'}), 403
    
    if container.suspended and not session.get('is_admin'):
        return jsonify({'success': False, 'error': 'Container suspended'}), 403
    
    if LXCManager.start_container(container.name):
        container.status = 'Running'
        container.suspended = False
        db.session.commit()
        log_action(f"Started: {container.name}")
        return jsonify({'success': True})
    
    return jsonify({'success': False, 'error': 'Failed to start'}), 500

@app.route('/container/<int:container_id>/stop', methods=['POST'])
@login_required
def stop_container(container_id):
    container = Container.query.get_or_404(container_id)
    
    shared_with = json.loads(container.shared_with)
    if container.user_id != session['user_id'] and session['user_id'] not in shared_with and not session.get('is_admin'):
        return jsonify({'success': False, 'error': 'Access denied'}), 403
    
    if LXCManager.stop_container(container.name):
        container.status = 'Stopped'
        db.session.commit()
        log_action(f"Stopped: {container.name}")
        return jsonify({'success': True})
    
    return jsonify({'success': False, 'error': 'Failed to stop'}), 500

@app.route('/container/<int:container_id>/restart', methods=['POST'])
@login_required
def restart_container(container_id):
    container = Container.query.get_or_404(container_id)
    
    shared_with = json.loads(container.shared_with)
    if container.user_id != session['user_id'] and session['user_id'] not in shared_with and not session.get('is_admin'):
        return jsonify({'success': False, 'error': 'Access denied'}), 403
    
    if container.suspended and not session.get('is_admin'):
        return jsonify({'success': False, 'error': 'Container suspended'}), 403
    
    if LXCManager.restart_container(container.name):
        container.status = 'Running'
        db.session.commit()
        log_action(f"Restarted: {container.name}")
        return jsonify({'success': True})
    
    return jsonify({'success': False, 'error': 'Failed to restart'}), 500

@app.route('/container/<int:container_id>/delete', methods=['POST'])
@login_required
def delete_container(container_id):
    container = Container.query.get_or_404(container_id)
    
    if container.user_id != session['user_id'] and not session.get('is_admin'):
        return jsonify({'success': False, 'error': 'Access denied'}), 403
    
    if LXCManager.delete_container(container.name):
        log_action(f"Deleted: {container.name}")
        db.session.delete(container)
        db.session.commit()
        return jsonify({'success': True})
    
    return jsonify({'success': False, 'error': 'Failed to delete'}), 500

@app.route('/container/<int:container_id>/snapshot', methods=['POST'])
@login_required
def create_snapshot(container_id):
    container = Container.query.get_or_404(container_id)
    
    if container.user_id != session['user_id'] and not session.get('is_admin'):
        return jsonify({'success': False, 'error': 'Access denied'}), 403
    
    description = request.json.get('description', '')
    snapshot_name = f"snap-{datetime.now().strftime('%Y%m%d-%H%M%S')}"
    
    if LXCManager.create_snapshot(container.name, snapshot_name):
        snapshot = ContainerSnapshot(
            container_id=container.id,
            snapshot_name=snapshot_name,
            description=description
        )
        db.session.add(snapshot)
        db.session.commit()
        log_action(f"Snapshot created: {snapshot_name}")
        return jsonify({'success': True})
    
    return jsonify({'success': False, 'error': 'Failed'}), 500

@app.route('/container/<int:container_id>/restore/<int:snapshot_id>', methods=['POST'])
@login_required
def restore_snapshot(container_id, snapshot_id):
    container = Container.query.get_or_404(container_id)
    snapshot = ContainerSnapshot.query.get_or_404(snapshot_id)
    
    if container.user_id != session['user_id'] and not session.get('is_admin'):
        return jsonify({'success': False, 'error': 'Access denied'}), 403
    
    if LXCManager.restore_snapshot(container.name, snapshot.snapshot_name):
        log_action(f"Restored: {snapshot.snapshot_name}")
        return jsonify({'success': True})
    
    return jsonify({'success': False, 'error': 'Failed'}), 500

@app.route('/admin')
@admin_required
def admin_panel():
    users = User.query.all()
    containers = Container.query.all()
    logs = AuditLog.query.order_by(AuditLog.timestamp.desc()).limit(50).all()
    
    for container in containers:
        container.status = LXCManager.get_container_status(container.name)
    db.session.commit()
    
    stats = {
        'total_users': len(users),
        'total_containers': len(containers),
        'running_containers': sum(1 for c in containers if c.status == 'Running'),
        'suspended_containers': sum(1 for c in containers if c.suspended),
        'host_cpu': get_host_cpu_usage(),
        'monitoring_active': monitoring_active
    }
    
    return render_template('admin/panel.html', users=users, containers=containers, logs=logs, stats=stats)

@app.route('/admin/create-container', methods=['GET', 'POST'])
@admin_required
def admin_create_container():
    if request.method == 'POST':
        user_id = request.form.get('user_id', type=int)
        ram_gb = request.form.get('ram_gb', type=int)
        cpu_cores = request.form.get('cpu_cores', type=int)
        disk_gb = request.form.get('disk_gb', type=int)
        
        user = User.query.get_or_404(user_id)
        
        container_count = Container.query.filter_by(user_id=user_id).count() + 1
        container_name = f"gvm-{user.username}-{container_count}"
        ssh_password = secrets.token_urlsafe(12)
        
        result = LXCManager.create_container(container_name, ram_gb, cpu_cores, disk_gb, ssh_password)
        
        if result['success']:
            container = Container(
                name=container_name,
                user_id=user_id,
                ram_gb=ram_gb,
                cpu_cores=cpu_cores,
                disk_gb=disk_gb,
                status='Running',
                ssh_password=ssh_password
            )
            db.session.add(container)
            db.session.commit()
            
            log_action(f"Created container: {container_name}")
            flash(f'Container created for {user.username}', 'success')
            return redirect(url_for('admin_panel'))
        else:
            flash(f'Failed: {result.get("error")}', 'danger')
    
    users = User.query.all()
    return render_template('admin/create_container.html', users=users)

@app.route('/admin/user/<int:user_id>/toggle-admin', methods=['POST'])
@admin_required
def toggle_admin(user_id):
    user = User.query.get_or_404(user_id)
    
    if user.id == session['user_id']:
        return jsonify({'success': False, 'error': 'Cannot modify own status'}), 403
    
    user.is_admin = not user.is_admin
    db.session.commit()
    log_action(f"Toggled admin for: {user.username}")
    return jsonify({'success': True, 'is_admin': user.is_admin})

@app.route('/admin/container/<int:container_id>/suspend', methods=['POST'])
@admin_required
def suspend_container(container_id):
    container = Container.query.get_or_404(container_id)
    reason = request.json.get('reason', 'Admin suspended')
    
    LXCManager.stop_container(container.name)
    container.suspended = True
    container.status = 'Stopped'
    
    history = json.loads(container.suspension_history)
    history.append({
        'time': datetime.now().isoformat(),
        'reason': reason,
        'by': session.get('username', 'Admin')
    })
    container.suspension_history = json.dumps(history)
    db.session.commit()
    
    log_action(f"Suspended: {container.name}", reason)
    return jsonify({'success': True})

@app.route('/admin/container/<int:container_id>/unsuspend', methods=['POST'])
@admin_required
def unsuspend_container(container_id):
    container = Container.query.get_or_404(container_id)
    container.suspended = False
    db.session.commit()
    log_action(f"Unsuspended: {container.name}")
    return jsonify({'success': True})

@app.route('/api/container/<int:container_id>/stats')
@login_required
def api_container_stats(container_id):
    container = Container.query.get_or_404(container_id)
    
    shared_with = json.loads(container.shared_with)
    if container.user_id != session['user_id'] and session['user_id'] not in shared_with and not session.get('is_admin'):
        return jsonify({'error': 'Access denied'}), 403
    
    stats = LXCManager.get_container_stats(container.name)
    status = LXCManager.get_container_status(container.name)
    
    return jsonify({'status': status, 'stats': stats})

# ========================
# Database Initialization
# ========================

def init_db():
    """Initialize database"""
    with app.app_context():
        # Create directory
        os.makedirs('/var/lib/gvm-panel', exist_ok=True)
        
        # Create tables
        db.create_all()
        
        # Create admin
        admin = User.query.filter_by(username='admin').first()
        if not admin:
            admin = User(username='admin', email='admin@gvmpanel.local', is_admin=True)
            admin.set_password('admin')
            db.session.add(admin)
            db.session.commit()
            logger.info("Admin user created")
        
        # Start monitoring
        start_monitoring()
        logger.info("GVM Panel initialized")

# ========================
# Main
# ========================

if __name__ == '__main__':
    init_db()
    logger.info("Starting GVM Panel v2.0...")
    app.run(host='0.0.0.0', port=5000, debug=False, threaded=True)
